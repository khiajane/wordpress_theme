<?php
get_header();
?>
 <!--main layout-->
<main class="my-5">
    <div class="container">
        <div class="row">
            <!--Grid column-->
            <div class="col-md-7">
             <img src="<?php bloginfo('stylesheet_directory'); ?>/img/layout/main_sws.jpg" class="img-fluid">
             <!--<img src="img/layout/Main-image.jpg" class="img-fluid">-->
            </div>
<!--End of First Grid column-->
<!--Grid column-->
            <div class="col-md-5">
             <h1 class="display-4" style="font-family: century; color:#646464; "> NEW ALBUM RELEASED</h1>
            <br>
              
            <p>Sleeping With Sirens' fifth studio album shows the band drifting away from their post-hardcore influences into a pop-influenced sound. It was released on September 22, 2017 through Warner Bros Records and it’s the band’s first release since their departure from Epitaph Records.</p>
            <a href="#" style="color:#ff9900;">READ MORE>></a>
        
        </div>
    </div>
    <!--Blog Section-->
 <section id="blog">
    <div class="container-fluid" >
    <hr class="mt-5">
    </div>
<div class="row">
    <div class="col-md-4" mb-4>
        
        <!-- Card content -->
        <div class="text-justify">
         <div class="card-body">

            <!-- Title -->
            <h4 class="card-title"><a>Gossip Album 2017</a></h4>
            <!-- Text -->
             <p class="card-text">Some quick example text to build on the card title and make up the bulk of the card's content.</p>
            <!-- Button -->
            <a href="#" style="color:#ff9900;">READ MORE>></a>>
            <!-- Card -->
            <div class="card">

            <!-- Card image -->
            <img src="<?php bloginfo('stylesheet_directory'); ?>/img/layout/album_1.jpg" class="card-img-top" alt="Card image cap">
           
            </div>
        </div>
    </div>
        <!-- Card -->
    </div>
<div class="col-md-4">
        
        <!-- Card content -->
        <div class="text-justify">
         <div class="card-body">

            <!-- Title -->
            <h4 class="card-title"><a>Madness(Deluxe Edition)</a></h4>
            <!-- Text -->
             <p class="card-text">Some quick example text to build on the card title and make up the bulk of the card's content.</p>
            <!-- Button -->
            <a href="#" style="color:#ff9900;">READ MORE>></a>>
            <!-- Card -->
            <div class="card">

            <!-- Card image -->
             <img src="<?php bloginfo('stylesheet_directory'); ?>/img/layout/album_2.jpg" class="card-img-top" alt="Card image cap">
           
            
            </div>
        </div>
        </div>
        <!-- Card -->
    </div>
<div class="col-md-4">
        
        <!-- Card content -->
        <div class="text-justify">
         <div class="card-body">

            <!-- Title -->
            <h4 class="card-title"><a>Live and Unplugged</a></h4>
            <!-- Text -->
             <p class="card-text">Some quick example text to build on the card title and make up the bulk of the card's content.</p>
            <!-- Button -->
            <a href="#" style="color:#ff9900;">READ MORE>></a>>
            <!-- Card -->
            <div class="card">

            <!-- Card image -->

             <img src="<?php bloginfo('stylesheet_directory'); ?>/img/layout/album_3.jpg" class="card-img-top" alt="Card image cap">
           
            </div>
        </div>
        </div>
        <!-- Card -->
    </div>

</div>

<div class="row">
    
    <div class="col-md-4">
        
        <!-- Card content -->
        <div class="text-justify">
         <div class="card-body">

            <!-- Title -->
            <h4 class="card-title"><a>Let's Cheers to this</a></h4>
            <!-- Text -->
             <p class="card-text">Some quick example text to build on the card title and make up the bulk of the card's content.</p>
            <!-- Button -->
            <a href="#" style="color:#ff9900;">READ MORE>></a>>
            <!-- Card -->
            <div class="card">

            <!-- Card image -->
             <img src="<?php bloginfo('stylesheet_directory'); ?>/img/layout/album_4.jpg" class="card-img-top" alt="Card image cap">
           
           
            </div>
        </div>
        </div>
        <!-- Card -->
    </div>
<div class="col-md-4">
        
        <!-- Card content -->
        <div class="text-justify">
         <div class="card-body">

            <!-- Title -->
            <h4 class="card-title"><a>With ears to see and eyes to hear</a></h4>
            <!-- Text -->
             <p class="card-text">Some quick example text to build on the card title and make up the bulk of the card's content.</p>
            <!-- Button -->
            <a href="#" style="color:#ff9900;">READ MORE>></a>>
            <!-- Card -->
            <div class="card">

            <!-- Card image -->
             <img src="<?php bloginfo('stylesheet_directory'); ?>/img/layout/album_5.jpg" class="card-img-top" alt="Card image cap">
           

            </div>
        </div>
        </div>
        <!-- Card -->
    </div>
<div class="col-md-4">
        
        <!-- Card content -->
        <div class="text-justify">
         <div class="card-body">

            <!-- Title -->
            <h4 class="card-title"><a>If you were a movie, this would be your soundtrack</a></h4>
            <!-- Text -->
             
             <p class="card-text" >Some quick example text to build on the card title and make up the bulk of the card's content.</p>
            <!-- Button -->
            <a href="#" style="color:#ff9900;">READ MORE>></a>>
            <!-- Card -->
            <div class="card">
            </div>
            <!-- Card image -->
             <img src="<?php bloginfo('stylesheet_directory'); ?>/img/layout/album_6.jpg" class="card-img-top" alt="Card image cap">
           
           
            </div>

        </div>
        <!-- Card -->
        
    </div>

</div>
</section>
<!--About section-->
<section id="about">
<br>
<hr>

<div class="row">
    <div class="col">
        <h5>Sleeping with Sirens</h5>
            <hr>
            <p style="color:#ff9900;">Sleeping with Sirens is an American rock band from Orlando, Florida currently residing in Grand Rapids, Michigan. The band currently consists of Kellin Quinn (vocals, keyboards), Gabe Barham (drums), Jack Fowler (lead guitar), Nick Martin (rhythm guitar), and Justin Hills (bass). </p>
        
    </div>
    <div class="col">
        <h5>The Band formed</h5>
            <hr>
            <p style="color:#ff9900;">The band was formed in 2009 by members of For All We Know and Paddock Park. The group is currently signed to Warner Bros. Records and have released five full-length albums and an acoustic EP. They rose to fame by their song "If I'm James Dean, You're Audrey Hepburn" which is the lead single from their debut album With Ears to See and Eyes to Hear which released in 2010. </p>
        
    </div>
    <div class="col">
        <h5>About the Album</h5>
            <hr>
            <p style="color:#ff9900;">Their second album Let's Cheers to This was released in 2011 and became a breakout for the band, thanks to the popular single “If You Can’t Hang” The group's third album Feel debuted at No. 3 on the US Billboard 200, and a fourth album entitled Madness was released on March 17, 2015 through Epitaph Records and spawned the single "Kick Me". .</p>
        
    </div>
    <div class="col">
        <h5>Members</h5>
            <hr>
            <p style="color:#ff9900;">Kellin Quinn – lead vocals, keyboards (2009–present)
             Gabe Barham – drums, percussion (2009–present)
        Justin Hills – bass guitar, backing vocals (2009–present)
         Jack Fowler – lead guitar, programming (2010–present)
            Nick Martin – rhythm guitar, vocals (2013–present)</p>
        
    </div>
    <div class="col">
        <h5>Music styles</h5>
            <hr>
            <p style="color:#ff9900;">Musical style
The band's music has been described as post-hardcore,pop rock, metal core and Alternative rock</p>
        
    </div>
</div>
</section>
 <section id="contact">
    <br>
    <hr>
     <!--main layout-->
       
    </div><!-- #primary -->

 <!-- Contact Section -->
 
      <div class="container">
        <h2 class="text-center text-uppercase " style="font-family: Times New Roman; color:#646464">Contact Me</h2>
        <hr class="star-dark mb-5">
        <div class="row">
          <div class="col-lg-8 mx-auto">
            <!-- To configure the contact form email address, go to mail/contact_me.php and update the email address in the PHP file on line 19. -->
            <!-- The form should work on most web servers, but if the form is not working you may need to configure your web server differently. -->

            <?php echo do_shortcode('[contact-form-7 id="40" title="Contact form 1"]');?>

            <!-- <form name="sentMessage" id="contactForm" novalidate="novalidate">
              <div class="control-group">
                <div class="form-group floating-label-form-group controls mb-0 pb-2">
                  <label>Name</label>
                  <input class="form-control" id="name" type="text" placeholder="Name" required="required" data-validation-required-message="Please enter your name.">
                  <p class="help-block text-danger"></p>
                </div>
              </div>
              <div class="control-group">
                <div class="form-group floating-label-form-group controls mb-0 pb-2">
                  <label>Email Address</label>
                  <input class="form-control" id="email" type="email" placeholder="Email Address" required="required" data-validation-required-message="Please enter your email address.">
                  <p class="help-block text-danger"></p>
                </div>
              </div>
              <div class="control-group">
                <div class="form-group floating-label-form-group controls mb-0 pb-2">
                  <label>Phone Number</label>
                  <input class="form-control" id="phone" type="tel" placeholder="Phone Number" required="required" data-validation-required-message="Please enter your phone number.">
                  <p class="help-block text-danger"></p>
                </div>
              </div>
              <div class="control-group">
                <div class="form-group floating-label-form-group controls mb-0 pb-2">
                  <label>Message</label>
                  <textarea class="form-control" id="message" rows="5" placeholder="Message" required="required" data-validation-required-message="Please enter a message."></textarea>
                  <p class="help-block text-danger"></p>
                </div>
              </div>
              <br>
              <div id="success"></div>
              <div class="form-group">
                <button type="submit" class="btn btn-dark btn-xl" id="sendMessageButton">Send</button>
              </div>
            </form> -->
          </div>
        </div>
      </div>
    </section>
     </main>
<?php
get_footer();
