<?php
function theme_styles() {

	
		wp_enqueue_style( 'bootstrap-min_css', get_template_directory_uri() . '/css/bootstrap.min.css' );
		wp_enqueue_style( 'bootstrap_css', get_template_directory_uri() . '/css/bootstrap.css' );
	wp_enqueue_style( 'main_css', get_template_directory_uri() . '/style.css' );
wp_enqueue_style('font-awesome-min_css', get_template_directory_uri() .'/css/font-awesome.min.css');
wp_enqueue_style('mdb_css', get_template_directory_uri() .'/css/mdb.css');
wp_enqueue_style('mdb-min_css', get_template_directory_uri() .'/css/mdb.min.css');
}

add_action( 'wp_enqueue_scripts', 'theme_styles');

function theme_js() {

	global $wp_scripts;

	wp_enqueue_script( 'bootsrap_js', get_template_directory_uri() . '/js/bootstrap.js', array ( 'jquery' ), 1.1, true);
	wp_enqueue_script( 'bootsrap-min_js', get_template_directory_uri() . '/js/bootstrap.min.js', array ( 'jquery' ), 1.1, true);
	wp_enqueue_script( 'script', get_template_directory_uri() . '/js/script.js', array ( 'jquery' ), 1.1, true); 
	wp_enqueue_script( 'jquery-3.2.1.min_js', get_template_directory_uri() . '/js/jquery-3.2.1.min.js', array ( 'jquery' ), 1.1, true);
	wp_enqueue_script( 'mdb_js', get_template_directory_uri() . '/js/mdb.js', array ( 'jquery' ), 1.1, true);
	wp_enqueue_script( 'mdb-min_js', get_template_directory_uri() . '/js/mdb.min.js', array ( 'jquery' ), 1.1, true);
	wp_enqueue_script( 'popper.min_js', get_template_directory_uri() . '/js/popper.min.js', array ( 'jquery' ), 1.1, true);

}


add_action( 'wp_enqueue_scripts', 'theme_js');
?>