        <!--footer-->
<footer class="page-footer font-small elegant-color pt-4 mt-4">
<div class="container">
                    <div class="row">
                     
                        <div class="col-sm-9 ">
                            <div class="copyright-text">
                                <p>CopyRight © 2017 Digital All Rights Reserved</p>
                            </div>
                        </div> <!-- End Col -->
                        <div class="col-sm-3">                          
                               <p>Template by: Khia Jane A. Bendanillo</p>               
                        </div> <!-- End Col -->
                    </div>
                   
                </div>
</div>
                    
       </footer> 
        <!--footer-->
<?php wp_footer();?>
          <!-- SCRIPTS -->
    
    <!-- JQuery -->
   <!-- <script type="text/javascript" src="js/jquery-3.2.1.min.js"></script>-->
    <!-- Bootstrap tooltips -->
   <!-- <script type="text/javascript" src="js/popper.min.js"></script>-->
    <!-- Bootstrap core JavaScript -->
    <!--<script type="text/javascript" src="js/bootstrap.min.js"></script>-->
    <!-- MDB core JavaScript -->
    <!--<script type="text/javascript" src="js/mdb.min.js"></script -->
</body>

</html>