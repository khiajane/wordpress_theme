
<!doctype html>
<html <?php language_attributes(); ?>>
<head>

    <meta charset="<?php bloginfo( 'charset' ); ?>">
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
    <meta charset="utf-8">
    <meta http-equiv="x-ua-compatible" content="ie=edge">
    <title>Sleeping with Sirens</title>
  
    <?php wp_head(); ?>
    <link rel="profile" href="http://gmpg.org/xfn/11">
    <!-- Font Awesome -->
      <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/font-awesome/4.7.0/css/font-awesome.min.css">
    <!-- Bootstrap core CSS -->
    <link href="css/bootstrap.min.css" rel="stylesheet">
    <!-- Material Design Bootstrap -->
    <link href="css/mdb.min.css" rel="stylesheet">
    <!-- Your custom styles (optional) -->
    <link href="css/style.css" rel="stylesheet">

</head>



    <header>

         <nav class="navbar navbar-expand-lg navbar-dark elegant-color-dark">

        <div class="container" >
         <!-- Collapse button -->
    <button class="navbar-toggler" type="button" data-toggle="collapse" data-target="#basicExampleNav" aria-controls="basicExampleNav"
        aria-expanded="false" aria-label="Toggle navigation">
        <span class="navbar-toggler-icon"></span>
    </button>

     <!-- Collapsible content -->
    <div class="collapse navbar-collapse" id="basicExampleNav">
  
        <!-- Links -->


      <div class="standard-na">
        <ul class="navbar-nav mr-auto">
            <li class="nav-item"  >
                <a  class="nav-link" href="#">Sign Up
                    <span class="sr-only">(current)</span>
                </a>
            </li>
            <li class="nav-item" >
                <a class="nav-link " href="#">RSS feed</a>
            </li>
            <li class="nav-item" >
                <a class="nav-link" href="#">News</a>
            </li>
            <li class="nav-item" >
                <a class="nav-link" href="#">Archive</a>
            </li>

        </ul>
        <!-- Links -->
    </div>
</div>
    <form class="form-inline">
            <!--
            <div class="md-form mt-0">
                <input class="form-control mr-sm-2" type="text" placeholder="Search" aria-label="Search">
            </div>-->
             <div class="input-group">
                <input class="form-control" type="text" aria-label="Search" style="padding-left: 2-0px; border-radius: 40px; padding: 0px 11px 0px 23px; " id="mysearch">
                <div class="input-group-addon" style="margin-left: -50px; z-index: 3; border-radius: 40px; background-color: transparent; border:none;">
                    <button class="btn btn-dark btn-sm" type="submit" style=" border-radius: 111px;  padding: 0px 4px 1px 5px;   margin-left: 25px;" id="search-btn">
                        <i class="fa fa-search" style="font-size:8px;"></i></button>
                </div>
            </div>
        </form>
    </div>
    </nav>
    <!-- #site-navigation -->
   

<!--/.Navbar-->

<!--header Site name-->
    <div class="my-5">
    <div class="container" >
         <div class="row">
            <div class="col-md-5">
            <h1 class="name" style="font-family: Times New Roman; color:#646464;"><?php bloginfo('name');?></h1>
            <span class="name"><?php bloginfo('description');?></span>
     <div class="mb-5 ">  </div> 
</div>
</div>
</div>
<!--End of headder site name-->

<nav class="navbar navbar-light navbar-expand-lg position:fixed" style="background-color: transparent;  box-shadow: none; height: 40px;     border-top:  double #eee !important;
    border-bottom:double #eee !important;">
        
        <div class="container" >
         <!-- Collapse button -->
    
    <div class="collapse navbar-collapse" id="basicExampleNav">
  
        <!-- Links -->


      <div class="standard-na">
  
        <ul class="navbar-nav mr-auto">
            <div class="col-3">   
            <li class=" nav-item"  >
            <a class="nav-link py-3 px-0 px-lg-3 rounded js-scroll-trigger" href="">Home</a>
                    <span class="sr-only">(current)</span>
                </a>
            </li>
             </div>
             <div class="col-3">  
            <li class="nav-item" >
                       <a class="nav-link py-3 px-0 px-lg-3 rounded js-scroll-trigger" href="#about">About</a>
            </li>
        </div>
            <li class="nav-item" >
                    <a class="nav-link py-3 px-0 px-lg-3 rounded js-scroll-trigger" href="#blog">Blog</a>
            </li>
            <li class="nav-item" >
               <a class="nav-link py-3 px-0 px-lg-3 rounded js-scroll-trigger" href="#contact">Contact</a>
            </li>

</ul>
        <!-- Links -->

        

</div>
   
    </div>
    </nav><!-- #site-navigation -->
</div>


    </header><!-- #masthead -->

    <div id="content" class="site-content">